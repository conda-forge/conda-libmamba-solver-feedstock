All of the people who have made at least one contribution to conda-libmamba-solver.
Authors are sorted alphabetically.

* Albert DeFusco
* Christopher Ostrouchov
* Daniel Holth
* Jaime Rodríguez-Guerra
* Jannis Leidel
* Ken Odegard
* Matthew R. Becker
* conda-bot
* pre-commit-ci[bot]
